import MapboxDirections from './directions';

module.exports = MapboxDirections;

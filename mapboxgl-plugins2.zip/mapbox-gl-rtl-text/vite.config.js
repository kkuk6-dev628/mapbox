export default {
  envPrefix: 'MAPBOX_'
}
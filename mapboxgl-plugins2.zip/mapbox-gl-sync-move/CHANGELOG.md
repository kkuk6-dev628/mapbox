# Changelog

## 0.3.0

- Add `off` method for cancelling synchronization
- Add `mapbox-gl` as peer dependency

## 0.2.0

- Add the ability to sync more than one map at a time.

## 0.1.0

- Initial release.

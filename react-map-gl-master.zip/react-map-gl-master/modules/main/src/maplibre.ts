export * from '@vis.gl/react-maplibre';

export {Map as default} from '@vis.gl/react-maplibre';

export * from '@vis.gl/react-mapbox';

export {Map as default} from '@vis.gl/react-mapbox';

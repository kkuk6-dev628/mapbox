import './deep-equal.spec';
import './transform.spec';
import './style-utils.spec';
import './apply-react-style.spec';

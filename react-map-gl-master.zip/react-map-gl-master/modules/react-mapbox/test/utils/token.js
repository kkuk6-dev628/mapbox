export const MapboxAccessToken = import.meta.env.VITE_MAPBOX_TOKEN;

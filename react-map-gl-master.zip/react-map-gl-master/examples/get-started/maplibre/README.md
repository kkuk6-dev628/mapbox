# react-map-gl Example: Using with Maplibre

This example shows a minimal app configuration to use react-map-gl with [Maplibre GL JS](https://maplibre.org/).

## Usage

```bash
npm i
npm run start
```

To build a production version:

```bash
npm run build
```

## Attribution

The basemap in this example is provided by [CARTO free basemap service](https://carto.com/basemaps).
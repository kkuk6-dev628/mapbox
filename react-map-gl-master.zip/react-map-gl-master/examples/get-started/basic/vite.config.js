export default {
  define: {
    'process.env.MapboxAccessToken': JSON.stringify(process.env.MapboxAccessToken)
  }
};

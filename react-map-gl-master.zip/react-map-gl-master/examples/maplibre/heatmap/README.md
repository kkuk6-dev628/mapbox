# Example: Heatmap layer

This app reproduces Maplibre's [Create a heatmap layer](https://maplibre.org/maplibre-gl-js/docs/examples/heatmap-layer/) example.

## Usage

```bash
npm i
npm run start
```

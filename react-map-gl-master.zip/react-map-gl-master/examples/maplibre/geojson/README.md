# Example: GeoJSON

This example showcases how to dynamically add and update custom data sources.

## Usage

```bash
npm i
npm run start
```

# Example: Draw Polygon

This app reproduces Mapbox's [Draw a polygon and calculate its area](https://docs.mapbox.com/mapbox-gl-js/example/mapbox-gl-draw/) example.

## Usage

```bash
npm i
npm run start
```

# Example: Highlight By Filter

This app reproduces Mapbox's [Highlight features containing similar data](https://www.mapbox.com/mapbox-gl-js/example/query-similar-features/) example.

This example showcases how to dynamically add/remove filters from layers.

## Usage

```bash
npm i
npm run start
```

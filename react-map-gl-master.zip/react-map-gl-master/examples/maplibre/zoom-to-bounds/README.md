# Example: Zoom To Bounds

Demonstrates how to zoom to a bounding box with react-maplibre.

## Usage

```bash
npm i
npm run start
```

# Example: Supercluster

This app reproduces Maplibre's [Create and style clusters](https://maplibre.org/maplibre-gl-js/docs/examples/cluster/) example.

This example showcases how to visualize points as clusters.

## Usage

```bash
npm i
npm run start
```

# Example: Animated GeoJSON

This app reproduces Maplibre's [Animate point along line](https://maplibre.org/maplibre-gl-js/docs/examples/animate-point-along-line/) example.

This example showcases how to dynamically add and update custom data sources.

## Usage

```bash
npm i
npm run start
```

# Example: Draggable Marker

Demonstrates how Marker component can be dragged with react-maplibre.

## Usage

```bash
npm i
npm run start
```

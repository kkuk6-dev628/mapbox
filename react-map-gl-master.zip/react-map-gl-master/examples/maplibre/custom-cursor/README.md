# Example: Custom Cursor

This example showcases how to dynamically change the cursor over the map based on interactivity.

## Usage

```bash
npm i
npm run start
```

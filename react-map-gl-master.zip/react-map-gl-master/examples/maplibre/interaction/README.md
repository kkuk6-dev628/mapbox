# Example: Interaction

This example showcases how to toggle/limit user interaction.

## Usage

```bash
npm i
npm run start
```

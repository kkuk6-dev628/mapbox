# Example: Controls

Demonstrates how various control components can be used with react-maplibre.

## Usage

```bash
npm i
npm run start
```

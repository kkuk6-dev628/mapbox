# Example: Side By Side

Demonstrates how to synchronize two maps with react-maplibre.

## Usage

```bash
npm i
npm run start
```

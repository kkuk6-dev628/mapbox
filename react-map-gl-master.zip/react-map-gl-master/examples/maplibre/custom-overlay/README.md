# Example: SVG overlay

This app shows how to implement a custom control that draws arbitrary React content that responds to camera updates.

## Usage

```bash
npm i
npm run start
```

# Example: 3D Terrain

This app reproduces Maplibre's [3D terrain](https://maplibre.org/maplibre-gl-js/docs/examples/3d-terrain/) example.

## Usage

```bash
npm i
npm run start
```

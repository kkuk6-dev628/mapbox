# Example: Globe

This app reproduces Maplibre's [globe](https://maplibre.org/maplibre-gl-js/docs/examples/globe/) example.

## Usage

```bash
npm i
npm run start
```

# Example: Viewport Animation

This example showcases how to transition smoothly between one viewport to another.

## Usage

```bash
npm i
npm run start
```

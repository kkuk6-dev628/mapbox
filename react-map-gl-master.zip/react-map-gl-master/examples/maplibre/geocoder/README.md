# Example: Geocoder

This app reproduces Maplibre's [Geocode with Nominatim](https://maplibre.org/maplibre-gl-js/docs/examples/geocoder/) example.

## Usage

```bash
npm i
npm run start
```
